export class Credit {
    issuer;
    limit;
    monthly_usage;
    monthly_pay;
    type;
    roi;
    balance;
}
