export class Loan {

    loan_type;
    lender;
    applicant: '';
    amnt;
    ldate: '';
    check: '';
    tenure;
    intrest_type: '';
    roi;
    rdate: '';

    constructor() { }
}
