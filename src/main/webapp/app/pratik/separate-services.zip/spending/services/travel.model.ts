export class Travel {
    food;
    entertainment;
    dineout;
    vacation;
    hobby;
}
