export class General {
    policy_no;
    issuer;
    policy_name;
    start_date;
    premium;
    proposer_name;
    ins_obj;
    policy_term;
    sum;
}
