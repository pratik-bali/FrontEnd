export class Income {
    incomeSalary: 0;
    incomeAward: 0;
    incomeBonus: 0;
    incomePension: 0;
    incomeSaving: 0;
    incomeDeposit: 0;
    incomeRental: 0;
    IncomeArray: any = [];
    constructor() {

    }
}
