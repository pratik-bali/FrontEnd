export class Life {
    type;
    issuer;
    ins_name;
    proposer_name;
    start_date;
    policy_term;
    premium_mode;
    policy_name;
    sum;
    premium;
    premium_term;

    constructor() { }
}
