export class House {
    milk;
    fruit;
    rent;
    fuel;
    medical;
    society;
    auto;
    edu;
    grocery;
    servent;
    laundry;
    vcd;
    selfcare;
    property;
}
