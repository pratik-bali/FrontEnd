export class Utility {
    electricity;
    gas;
    water;
    telephone;
    mobile;
    internet;
    tv;
    vcd;
    news;
    UtilityArray = [];
}
