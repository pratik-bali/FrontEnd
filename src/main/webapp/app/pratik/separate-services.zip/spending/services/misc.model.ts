export class Misc {
    shoes;
    pet;
    electronics;
    furniture;
    charity;
    gift;
    cloth;
}
