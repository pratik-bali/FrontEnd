export class Health {
    policy_no;
    issuer;
    policy_name;
    proposer_name;
    policy_term;
    start_date;
    premium_mode;
    ins_name;
    sum;
    premium;
}
